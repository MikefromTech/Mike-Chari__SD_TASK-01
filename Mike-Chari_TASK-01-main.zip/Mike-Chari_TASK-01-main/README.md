
# Temperature Conversion Program

This programming task has been assigned by Prodigy Infotech as part of the software development internship.
## Description

The Temperature Unit Converter is a simple Python program that allows users to convert temperatures between Celsius, Fahrenheit, and Kelvin scales. With this program, users can easily input a temperature value along with the original unit of measurement, and the program will swiftly convert the temperature to the other two units and display the converted values.

## Features

- Converts temperatures between Celsius, Fahrenheit, and Kelvin scales.
- User-friendly interface with prompt-based input.
- Accurate and efficient conversion calculations.
- Provides clear and easy-to-read converted temperature values.

## How to Use

1. Clone this repository to your local machine using `git clone`.
2. Navigate to the project directory.
3. Run the program using a Python interpreter: `python temperature_converter.py`.
4. Follow the prompts to input a temperature value and the original unit of measurement.
5. The program will display the converted temperature values in the other two units.

## Example

Suppose you input a temperature of 25 degrees Celsius:

```
Temperature Conversion Program
-------------------------------
Enter the temperature value: 25
Enter the original unit (Celsius, Fahrenheit, or Kelvin): celsius

25.00 Celsius is equivalent to:
77.00 Fahrenheit
298.15 Kelvin
```

**Author:** Mangesh Pangam<br>
**GitHub:** [Mangesh2704](https://github.com/Mangesh2704)  
**Email:** 202103036.mangeshpkr@student.xavier.ac.in  

